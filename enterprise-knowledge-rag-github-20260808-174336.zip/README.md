# Enterprise Knowledge RAG

面向企业知识库场景的精简版 RAG 应用。项目参考 RAGFlow 等开源企业知识库系统的工程思路，独立实现一条可解释、可部署、可扩展的 RAG 链路。

## 当前阶段

第 1 阶段：文档接入与解析链路。

- FastAPI 后端
- React/Vite 前端
- 文档上传接口
- 文档元数据本地落库
- PDF/TXT/Markdown/DOCX 文本解析
- Chunk 分块与页码溯源
- 轻量 embedding 向量化
- Qdrant 向量入库
- 向量检索测试
- PostgreSQL 数据库预留
- Qdrant 向量库预留
- Docker Compose 本地部署预留

## 技术栈

- Frontend: React, TypeScript, Vite
- Backend: FastAPI, Pydantic, SQLAlchemy
- Parser: pypdf, python-docx
- Database: SQLite for local development, PostgreSQL reserved
- Vector Database: Qdrant
- LLM: DeepSeek
- Embedding: BGE 系列模型
- Deployment: Docker Compose

## 本地开发

后端：

```bash
cd backend
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

前端：

```bash
cd frontend
npm install
npm run dev
```

访问：

- Frontend: http://localhost:5173
- Backend health: http://localhost:8001/api/health

## 已实现 API

| Method | Path | Description |
| --- | --- | --- |
| GET | `/api/health` | 后端健康检查 |
| POST | `/api/documents/upload` | 上传文档并保存元数据 |
| GET | `/api/documents` | 查询文档列表 |
| POST | `/api/documents/{document_id}/parse` | 解析文档并生成 chunks |
| GET | `/api/documents/{document_id}/chunks` | 查询文档分块结果 |
| POST | `/api/documents/{document_id}/index` | 将 chunks 向量化并写入 Qdrant |
| GET | `/api/search?query=...` | 根据问题召回相关 chunks |

## 6 周升级路线

1. 工程骨架、文档上传入口、元数据管理
2. PDF 解析与 chunk 分块
3. Embedding 生成与 Qdrant 入库
4. BM25 + 向量混合检索
5. DeepSeek 问答与引用溯源
6. Docker 部署、README、简历包装、面试复盘
